/* Define if your struct tm has gmtoff */
#undef HAVE_TM_GMTOFF
